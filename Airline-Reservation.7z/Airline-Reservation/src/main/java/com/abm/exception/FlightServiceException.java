package com.abm.exception;

public class FlightServiceException extends RuntimeException {
	public FlightServiceException(String msg) {
		super(msg);
	}
}
