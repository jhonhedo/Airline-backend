package com.abm.exception;

public class ReservationServiceException extends RuntimeException {
 
	public  ReservationServiceException(String msg) {
		super(msg);
	}
	
}
