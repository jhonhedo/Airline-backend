package com.abm.exception;

public class UserServiceException  extends RuntimeException{

	public UserServiceException(String msg) {
		super(msg);
	}
}
