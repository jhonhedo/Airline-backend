package com.abm.exception;

public class AirlineServiceException extends RuntimeException {

	public AirlineServiceException(String msg) {
		super(msg);
	}
}
