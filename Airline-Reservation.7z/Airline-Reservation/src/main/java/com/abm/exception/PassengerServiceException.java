package com.abm.exception;

public class PassengerServiceException extends RuntimeException {
  
	public PassengerServiceException(String msg) {
		super(msg);
	}
	
}
